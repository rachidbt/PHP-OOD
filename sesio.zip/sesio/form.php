<?php
session_start();

$db = new mysqli('localhost','phpmyadmin','Felanitx2','variables');

$usuari = $_SESSION['usuari'];
$color = $_SESSION['color'];

$_SESSION['password']=$_REQUEST['passwd'];
$password=$_SESSION['password'];
if ($password){
  $query_update2="update var_sessio set password='$password' where usuari='$usuari'";
  $result1= $db->query($query_update2);
  echo "La password es ". $password. "<br>";
  echo "El usuari es ". $usuari. "<br>";
  echo "El color es ". $color. "<br>";
}
?>
<HTML>

<head>

    <title>VERIFICAR CONTRA</title>

    <style>body {background-color: <?php echo $color;?>}</style>
</head>

<body>

</body>

</HTML>
