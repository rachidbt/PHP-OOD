<?php

session_start();

$usuari = $_SESSION['usuari'];
$color = $_SESSION['color'];
$db = new mysqli('localhost','phpmyadmin','Felanitx2','variables');
$query_update="update var_sessio set visites=visites+1 where usuari='$usuari'";
$result= $db->query($query_update);
?>

    <HTML>

    <head>

        <title>...i acabem l'exemple de variables de sessió!</title>
	<style>
		body {
  			background-color: <?php echo $color ?>;
		}
	</style>
    </head>

    <body>

        <?php

echo "Usuari que havíeu escrit era: ".$_SESSION['usuari'];echo "<br>";

echo "El color  que havíeu escrit era: ".$_SESSION['color'];


//$db1 = new mysqli('localhost','phpmyadmin','Felanitx2','variables');
//$query_select="select visites from var_sessio where usuari='$usuari'";
//$result1= $db1->query($query_select);
//if ($result1 > 4) {
  //echo "<form action='form.php' method='post'> POSA LA TEVA CONTRASENYA:<input type='password' name='passwd'> <input type='submit' value='Envia!'></form>";
//}
$db->close();
?>

    </body>

    </HTML>
